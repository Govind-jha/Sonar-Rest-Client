package com.kumar.SonarQC;

import org.sonar.wsclient.Sonar;
import org.sonar.wsclient.services.Resource;
import org.sonar.wsclient.services.ResourceQuery;
import org.sonar.wsclient.services.ServerQuery;

public class App {
	public static void main(String[] args) {
		String host = "http://localhost:9000";
		String username = "admin";
		String password = "admin";
		String resourceKey = "JAVA:JSONtoSTUB";
		
		Sonar sonar = Sonar.create(host, username, password);

		// print Version
		System.out.println("Version" + getSonarVersion(sonar));
		
		// print Compliance
		System.out.println(getDupliactedLines(sonar, resourceKey));

		ResourceQuery query = ResourceQuery.createForMetrics(resourceKey, "coverage", "lines", "violations");
		System.out.println("URL: " + query.getUrl());
		Resource res = sonar.find(query);
		System.out.println("Resource: " + res);
		System.out.println("Lines" + res.getMeasure("violations"));
	}

	private static String getSonarVersion(Sonar sonar) {
		ServerQuery serverQuery = new ServerQuery();
		String version = sonar.find(serverQuery).getVersion();
		return version;
	}

	private static double getDupliactedLines(Sonar sonar, String resourceKey) {
		ResourceQuery query = new ResourceQuery(resourceKey);
		query.setMetrics("duplicated_lines");
		Resource r = sonar.find(query);
		return r.getMeasure("duplicated_lines").getValue();
	}
}
